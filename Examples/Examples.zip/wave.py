# ----------------------------------------------
# Script Recorded by Ansys Electronics Desktop Version 2024.2.0
# 20:53:48  May 09, 2025
# ----------------------------------------------
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.SetActiveProject("Spherical_Array")
oDesign = oProject.SetActiveDesign("Vertical_Array")
oModule = oDesign.GetModule("AnalysisSetup")
oModule.EditSetup("GPS_Band", 
	[
		"NAME:GPS_Band",
		"SolveType:="		, "Single",
		"Frequency:="		, "1.57542GHz",
		"MaxDeltaS:="		, 0.02,
		"UseMatrixConv:="	, False,
		"MaximumPasses:="	, 20,
		"MinimumPasses:="	, 2,
		"MinimumConvergedPasses:=", 5,
		"PercentRefinement:="	, 30,
		"IsEnabled:="		, True,
		[
			"NAME:MeshLink",
			"ImportMesh:="		, False
		],
		"BasisOrder:="		, 1,
		"DoLambdaRefine:="	, True,
		"DoMaterialLambda:="	, True,
		"SetLambdaTarget:="	, False,
		"Target:="		, 0.3333,
		"UseMaxTetIncrease:="	, False,
		"PortAccuracy:="	, 2,
		"UseABCOnPort:="	, False,
		"SetPortMinMaxTri:="	, False,
		"DrivenSolverType:="	, "Direct Solver",
		"EnhancedLowFreqAccuracy:=", False,
		"SaveRadFieldsOnly:="	, False,
		"SaveAnyFields:="	, True,
		[
			"NAME:ExpressionCache",
			[
				"NAME:CacheItem",
				"Title:="		, "dB_AxialRatioValue_1",
				"Expression:="		, "dB(AxialRatioValue)",
				"Intrinsics:="		, "Theta=\'90deg\' Phi=\'90deg\' ",
				"IsConvergence:="	, True,
				"UseRelativeConvergence:=", 0,
				"MaxConvergenceDelta:="	, 1,
				"MaxConvergeValue:="	, "0.02",
				"ReportType:="		, "Far Fields",
				[
					"NAME:ExpressionContext",
					"Context:="		, "3D"
				]
			]
		],
		"IESolverType:="	, "Auto",
		"LambdaTargetForIESolver:=", 0.15,
		"UseDefaultLambdaTgtForIESolver:=", True,
		"IE Solver Accuracy:="	, "Balanced",
		"InfiniteSphereSetup:="	, "",
		"MaxPass:="		, 10,
		"MinPass:="		, 1,
		"MinConvPass:="		, 1,
		"PerError:="		, 1,
		"PerRefine:="		, 30
	])
